plugins {
    id("com.android.application")
}

android {
    namespace = "com.serviciosclientes.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.serviciosclientes.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0-modern"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
