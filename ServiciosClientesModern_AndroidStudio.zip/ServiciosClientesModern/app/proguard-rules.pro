# Sin reglas especiales en esta versión.
