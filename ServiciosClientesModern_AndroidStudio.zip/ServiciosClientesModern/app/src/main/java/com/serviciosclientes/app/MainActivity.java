package com.serviciosclientes.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private final int NAVY = Color.rgb(15, 39, 71);
    private final int BLUE = Color.rgb(31, 111, 235);
    private final int BG = Color.rgb(245, 247, 250);
    private final int TEXT = Color.rgb(23, 43, 77);
    private final int MUTED = Color.rgb(94, 108, 132);
    private LinearLayout content;
    private final List<Branch> branches = new ArrayList<>();
    private SharedPreferences prefs;

    static class Branch {
        String client, branch, address, contact, phone, services, frequency, notes;
        int stations;
        Branch(String client, String branch, String address, String contact, String phone,
               String services, String frequency, String notes, int stations) {
            this.client=client; this.branch=branch; this.address=address; this.contact=contact;
            this.phone=phone; this.services=services; this.frequency=frequency; this.notes=notes;
            this.stations=stations;
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(NAVY);
        getWindow().setNavigationBarColor(Color.WHITE);
        prefs = getSharedPreferences("servicios_clientes", MODE_PRIVATE);
        seedData();
        showClients();
    }

    private void seedData() {
        branches.clear();
        branches.add(new Branch("Empresa Martínez y Cía Ltda.", "Planta Camino a San Javier",
                "Camino San Javier km 12, Talca", "José Pérez", "+56 9 1234 5678",
                "Control de roedores · Desinsectación", "Mensual",
                "Acceso por portería principal. Avisar al llegar.", 53));
        branches.add(new Branch("Supermercado Central", "Sucursal Talca Centro",
                "1 Oriente 1234, Talca", "María González", "+56 9 2345 6789",
                "Control de roedores · Sanitización", "Mensual",
                "Ingresar por recepción de proveedores.", 18));
        loadSavedBranches();
    }

    private void loadSavedBranches() {
        int n = prefs.getInt("count", 0);
        for (int i=0; i<n; i++) {
            String p="b"+i+"_";
            branches.add(new Branch(
                    prefs.getString(p+"client","Cliente"), prefs.getString(p+"branch","Sucursal"),
                    prefs.getString(p+"address",""), prefs.getString(p+"contact",""),
                    prefs.getString(p+"phone",""), prefs.getString(p+"services","Otro"),
                    prefs.getString(p+"frequency","Según programa"), prefs.getString(p+"notes",""),
                    prefs.getInt(p+"stations",0)));
        }
    }

    private LinearLayout baseScreen(String title, boolean back) {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(12),dp(8),dp(12),dp(8)); bar.setBackgroundColor(NAVY);
        if (back) { Button b=topButton("‹"); b.setOnClickListener(v -> showClients()); bar.addView(b, new LinearLayout.LayoutParams(dp(52),dp(52))); }
        TextView t = text(title, 20, Color.WHITE, true); t.setGravity(Gravity.CENTER_VERTICAL); bar.addView(t, new LinearLayout.LayoutParams(0,dp(56),1));
        root.addView(bar);
        ScrollView sv = new ScrollView(this); content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(14),dp(14),dp(14),dp(28)); sv.addView(content); root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));
        setContentView(root); return root;
    }

    private void showClients() {
        baseScreen("Clientes y sucursales", false);
        TextView subtitle=text("Toda la información de cada sucursal en un solo lugar",14,MUTED,false); content.addView(subtitle, lpMatchWrap(0,0,0,12));
        EditText search=new EditText(this); search.setHint("Buscar cliente o sucursal…"); search.setSingleLine(true); search.setPadding(dp(14),0,dp(14),0); search.setBackground(makeRounded(Color.WHITE, Color.rgb(220,226,235)));
        content.addView(search, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(52)));
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); content.addView(list, lpMatchWrap(0,12,0,12));
        Runnable render=()->{ list.removeAllViews(); String q=search.getText().toString().trim().toLowerCase(); for (Branch b:branches) if(q.isEmpty() || (b.client+" "+b.branch+" "+b.address).toLowerCase().contains(q)) list.addView(branchCard(b)); };
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){render.run();} public void afterTextChanged(android.text.Editable e){}}); render.run();
        Button add=primary("+ AGREGAR SUCURSAL"); add.setOnClickListener(v->showAddBranch()); content.addView(add,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(54)));
    }

    private View branchCard(Branch b) {
        LinearLayout card=card();
        TextView c=text(b.client,18,TEXT,true); card.addView(c);
        TextView s=text(b.branch,15,BLUE,true); card.addView(s,lpMatchWrap(0,3,0,7));
        card.addView(text("📍 "+b.address,14,MUTED,false));
        card.addView(text("👤 "+b.contact,14,MUTED,false),lpMatchWrap(0,5,0,0));
        card.setOnClickListener(v->showDetail(b)); return card;
    }

    private void showDetail(Branch b) {
        baseScreen("Detalle de la sucursal", true);
        LinearLayout head=card(); head.addView(text(b.client,20,TEXT,true)); head.addView(text(b.branch,16,BLUE,true),lpMatchWrap(0,4,0,0)); content.addView(head);
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); actions.setWeightSum(4); actions.setPadding(0,dp(10),0,dp(10));
        Button call=smallAction("Llamar"); call.setOnClickListener(v->openUri("tel:"+Uri.encode(b.phone))); actions.addView(call,new LinearLayout.LayoutParams(0,dp(50),1));
        Button wa=smallAction("WhatsApp"); wa.setOnClickListener(v->openUri("https://wa.me/"+digits(b.phone))); actions.addView(wa,new LinearLayout.LayoutParams(0,dp(50),1));
        Button map=smallAction("Mapa"); map.setOnClickListener(v->showMap(b)); actions.addView(map,new LinearLayout.LayoutParams(0,dp(50),1));
        Button go=smallAction("Cómo llegar"); go.setOnClickListener(v->openUri("https://www.google.com/maps/dir/?api=1&destination="+Uri.encode(b.address))); actions.addView(go,new LinearLayout.LayoutParams(0,dp(50),1));
        content.addView(actions);
        LinearLayout info=card(); addField(info,"Contacto",b.contact); addField(info,"Teléfono",b.phone); addField(info,"Dirección",b.address); addField(info,"Trabajos que se realizan",b.services); addField(info,"Frecuencia",b.frequency); addField(info,"Estaciones / cebaderas",String.valueOf(b.stations)); addField(info,"Observaciones",b.notes); content.addView(info);
        Button stations=primary("VER MAPA Y ESTACIONES ("+b.stations+")"); stations.setOnClickListener(v->showMap(b)); content.addView(stations,lpMatchWrap(0,12,0,0));
    }

    private void showMap(Branch b) {
        LinearLayout root=baseScreen("Mapa de estaciones", true);
        content.addView(text(b.client+" · "+b.branch,16,TEXT,true),lpMatchWrap(0,0,0,8));
        StationMapView mv=new StationMapView(this,b.stations); mv.setBackgroundColor(Color.WHITE); content.addView(mv,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(500)));
        TextView note=text("Los círculos azules representan las estaciones de la sucursal. En la versión online podremos cargar el plano o fotografía real de cada cliente y ubicar cada estación sobre ese mapa.",14,MUTED,false); content.addView(note,lpMatchWrap(0,12,0,0));
    }

    private void showAddBranch() {
        baseScreen("Agregar sucursal", true);
        EditText client=input("Nombre del cliente"); EditText branch=input("Nombre de la sucursal"); EditText address=input("Dirección"); EditText contact=input("Persona de contacto"); EditText phone=input("Teléfono"); phone.setInputType(InputType.TYPE_CLASS_PHONE); EditText services=input("Servicios (roedores, desinsectado, etc.)"); EditText stations=input("Cantidad de estaciones"); stations.setInputType(InputType.TYPE_CLASS_NUMBER); EditText notes=input("Observaciones");
        for(EditText e:new EditText[]{client,branch,address,contact,phone,services,stations,notes}) content.addView(e,lpMatchWrap(0,0,0,10));
        Button save=primary("GUARDAR SUCURSAL"); save.setOnClickListener(v->{
            if(client.getText().toString().trim().isEmpty() || branch.getText().toString().trim().isEmpty()){Toast.makeText(this,"Ingresa cliente y sucursal",Toast.LENGTH_SHORT).show();return;}
            int st=0; try{st=Integer.parseInt(stations.getText().toString().trim());}catch(Exception ignored){}
            saveBranch(new Branch(client.getText().toString().trim(),branch.getText().toString().trim(),address.getText().toString().trim(),contact.getText().toString().trim(),phone.getText().toString().trim(),services.getText().toString().trim(),"Según programa",notes.getText().toString().trim(),st));
            Toast.makeText(this,"Sucursal guardada",Toast.LENGTH_SHORT).show(); showClients();
        }); content.addView(save,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(54)));
    }

    private void saveBranch(Branch b){ int n=prefs.getInt("count",0); String p="b"+n+"_"; prefs.edit().putString(p+"client",b.client).putString(p+"branch",b.branch).putString(p+"address",b.address).putString(p+"contact",b.contact).putString(p+"phone",b.phone).putString(p+"services",b.services).putString(p+"frequency",b.frequency).putString(p+"notes",b.notes).putInt(p+"stations",b.stations).putInt("count",n+1).apply(); branches.add(b); }

    private void addField(LinearLayout p,String label,String value){ p.addView(text(label,12,MUTED,true),lpMatchWrap(0,6,0,0)); p.addView(text(value==null||value.isEmpty()?"—":value,16,TEXT,false),lpMatchWrap(0,1,0,7)); }
    private EditText input(String hint){ EditText e=new EditText(this);e.setHint(hint);e.setTextSize(16);e.setTextColor(TEXT);e.setHintTextColor(Color.rgb(130,140,155));e.setPadding(dp(14),0,dp(14),0);e.setBackground(makeRounded(Color.WHITE,Color.rgb(220,226,235)));e.setMinHeight(dp(52));return e; }
    private LinearLayout card(){ LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(16),dp(14),dp(16),dp(14));l.setBackground(makeRounded(Color.WHITE,Color.rgb(225,230,237)));LinearLayout.LayoutParams p=lpMatchWrap(0,0,0,10);l.setLayoutParams(p);l.setElevation(dp(2));return l; }
    private TextView text(String s,int sp,int color,boolean bold){ TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);return t; }
    private Button primary(String s){ Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(14);b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(BLUE));return b; }
    private Button smallAction(String s){ Button b=primary(s);b.setTextSize(11);b.setPadding(dp(2),0,dp(2),0);return b; }
    private Button topButton(String s){ Button b=new Button(this);b.setText(s);b.setTextSize(30);b.setTextColor(Color.WHITE);b.setBackgroundColor(Color.TRANSPARENT);b.setPadding(0,0,0,0);return b; }
    private LinearLayout.LayoutParams lpMatchWrap(int l,int t,int r,int b){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);p.setMargins(dp(l),dp(t),dp(r),dp(b));return p; }
    private android.graphics.drawable.GradientDrawable makeRounded(int fill,int stroke){ android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(14));g.setStroke(dp(1),stroke);return g; }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private String digits(String s){ return s==null?"":s.replaceAll("[^0-9]",""); }
    private void openUri(String u){ try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e){Toast.makeText(this,"No hay una aplicación disponible para abrir esta acción",Toast.LENGTH_SHORT).show();} }

    static class StationMapView extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); int count; Paint text=new Paint(Paint.ANTI_ALIAS_FLAG);
        StationMapView(android.content.Context c,int count){super(c);this.count=Math.max(1,count);p.setStrokeWidth(4);p.setStyle(Paint.Style.STROKE);text.setTextAlign(Paint.Align.CENTER);text.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); float w=getWidth(),h=getHeight(); p.setColor(Color.rgb(60,70,85)); c.drawRect(w*.08f,h*.14f,w*.42f,h*.42f,p); c.drawRect(w*.58f,h*.18f,w*.91f,h*.43f,p); c.drawRect(w*.17f,h*.58f,w*.83f,h*.86f,p); text.setColor(Color.DKGRAY);text.setTextSize(Math.max(24,w*.04f));c.drawText("PLANO DE ESTACIONES",w/2,h*.08f,text);
            int shown=Math.min(count,24); for(int i=0;i<shown;i++){ float x=w*(.10f+(i%8)*.115f); float y=h*(.20f+(i/8)*.22f); Paint fill=new Paint(Paint.ANTI_ALIAS_FLAG);fill.setColor(Color.rgb(31,111,235));fill.setStyle(Paint.Style.FILL);c.drawCircle(x,y,Math.max(16,w*.025f),fill);text.setColor(Color.WHITE);text.setTextSize(Math.max(14,w*.022f));c.drawText(String.valueOf(i+1),x,y+5,text);} text.setColor(Color.GRAY);text.setTextSize(Math.max(16,w*.025f));c.drawText("Total: "+count+" estaciones",w/2,h*.95f,text); }
    }
}
