# Servicios Clientes Modern — Android

Proyecto Android nativo modernizado para reemplazar la APK antigua bloqueada por Play Protect.

## Configuración
- `compileSdk 35`
- `targetSdk 35`
- `minSdk 26`
- Java 17
- Sin librerías de terceros ni permisos peligrosos
- No usa HTTP sin cifrar (`usesCleartextTraffic=false`)
- Cada sucursal guarda su propio contacto, teléfono, dirección, servicios, observaciones y cantidad de estaciones.
- Los datos agregados se guardan localmente en el teléfono con `SharedPreferences`.

## Generar APK instalable en Android Studio
1. Instala la versión actual de Android Studio.
2. Abre esta carpeta como proyecto.
3. Espera a que Android Studio complete **Gradle Sync** y descargue Android SDK 35 si hace falta.
4. Menú **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. El APK de prueba quedará normalmente en `app/build/outputs/apk/debug/app-debug.apk`.
6. Para distribución definitiva usa **Build > Generate Signed App Bundle / APK > APK** y crea/selecciona un keystore. Android Studio firmará el APK con los esquemas modernos compatibles (v2/v3 según configuración/toolchain).

## Importante
No reutilices la APK antigua. Compila este proyecto moderno y distribuye el APK nuevo.
